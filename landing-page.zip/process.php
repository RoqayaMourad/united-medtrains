<?php
        $EmailFrom = "From: United MedTrans USA Landing Page<info@unitedmedtransusa.com>";
        $EmailTo = "phillipe.lauture@gmail.com, info@unitedmedtransusa.com, jacknelsonquad@gmail.com, frankwilson.quad@gmail.com";
        $name    = $_POST['name-form'];
        $email   = $_POST['email-form'];
        $phone   = $_POST['phone-form'];
        $message = $_POST['message-form'];
        
        //echo $name." / ".$email." / ".$phone." / ".$message;die();
        
        $Body = "";
        $Body .= "Name: ";
        $Body .= $name;
        $Body .= "\n";
        $Body .= "Phone: ";
        $Body .= $phone;
        $Body .= "\n";
        $Body .= "Email: ";
        $Body .= $email;
        $Body .= "\n";
        $Body .= "Message: ";
        $Body .= $message;
        $Body .= "\n";
        $Body .= "\n";
        $Body .= "\n";
        $Body .= "This is message sent from United MedTrans USA landing page";

        $Subject = "Contact Form Submission(".$name.")";
        
 
        // send email 
        if(str_replace(' ', '', $name) != "" && str_replace(' ', '', $email)  != "" && str_replace(' ', '', $phone) != "" ){
            $data['success'] = mail($EmailTo, $Subject, $Body, $EmailFrom);
        }else{
            $data['success'] = "false";
        }

        // redirect to success page 
       if ($data['success'] == "false"){
            //echo json_encode($data);
            print "<meta http-equiv=\"refresh\" content=\"0;URL=thank-you.html\">";
       }
       else{
            // $data["success"] = $success  ;
            // echo json_encode($data);
            print "<meta http-equiv=\"refresh\" content=\"0;URL=index.html\">";
       }
?>